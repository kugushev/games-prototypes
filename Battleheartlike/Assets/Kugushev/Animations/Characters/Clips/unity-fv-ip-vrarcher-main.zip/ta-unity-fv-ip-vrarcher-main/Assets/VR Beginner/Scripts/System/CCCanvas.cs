﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CCCanvas : MonoBehaviour
{
    public Text CCText;
}
