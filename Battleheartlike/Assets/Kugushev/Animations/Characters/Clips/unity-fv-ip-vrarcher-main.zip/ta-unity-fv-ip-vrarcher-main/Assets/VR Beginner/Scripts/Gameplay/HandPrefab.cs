﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Utility script only use as a target of a GetComponent to retrieve the Animator from the hands use as model for the
//controller
public class HandPrefab : MonoBehaviour
{
    public Animator Animator;
}
